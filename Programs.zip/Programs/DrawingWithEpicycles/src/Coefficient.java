public record Coefficient(Double ampl, Double freq, Double phase) { }
